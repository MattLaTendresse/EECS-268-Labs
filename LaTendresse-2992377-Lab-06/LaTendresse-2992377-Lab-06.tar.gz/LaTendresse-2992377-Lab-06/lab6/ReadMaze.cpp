//
//  ReadMaze.cpp
//  lab6
//  the ReadMaze.cpp file is used to implement the methods that were defined in the ReadMaze.h and to define how to read in a maze to an array
//  Created by Matt LaTendresse on 4/3/21.
//

#include "ReadMaze.h"

ReadMaze::ReadMaze(std::string file)
{
    m_row = 0;
    m_col=0;
    read(file);
}

int ReadMaze::getRow() const
{
    return (m_row);
}

int ReadMaze::getCol() const
{
    return (m_col);
}

int ReadMaze::getStartRow() const
{
    return (m_startR);
}

int ReadMaze::getStartCol() const
{
    return (m_startC);
}

void ReadMaze::read(std::string file)
{
    std::ifstream input;
    int numIn;
    char charIn;
    input.open(file);
    if (input.is_open())
    {
        input >> numIn;
        m_row = numIn;
        input >> numIn;
        m_col = numIn;
        input >> numIn;
        m_startR = numIn;
        input >> numIn;
        m_startC = numIn;
        //check the entries we are given to see if we can even run it
        validParameters();

        m_maze = new char*[m_row];
        for (int i = 0; i < m_row; i++)
        {
            m_maze[i] = new char[m_col];
        }

        for (int i = 0; i < m_row; i++)
        {
            for (int j = 0; j < m_col; j++)
            {
                input >> charIn;
                m_maze[i][j] = charIn;
            }
        }

        if (m_maze[m_startR][m_startC] == 'W')
        {
            std::cout << "Start position is invalid\n";
            exit(1);
        }
    }
    else
    {
        std::cout << "File cannot be opened\n";
        exit(1);
    }
}

void ReadMaze::validParameters()
{
    if (m_row <=0)
    {
        std::cout << "Invalid starting position\n";
        exit(1);
    }
    if (m_col <=0)
    {
        std::cout << "Invalid starting position\n";
        exit(1);
    }
    if (m_startR <0 || m_startR >= m_row)
    {
        std::cout << "Start Row is not within range\n";
        exit(1);
    }
    if (m_startC <0 || m_startC >= m_col)
    {
        std::cout << "Start Column is not within range\n";
        exit(1);
    }
}

void ReadMaze::getMaze(char *maze[]) const
{
    for (int i = 0; i < m_row; i++)
    {
        for (int j = 0; j < m_col; j++)
        {
            maze[i][j] = m_maze[i][j];
        }
    }
}

void ReadMaze::printMaze()
{
    for (int i = 0; i < m_row; i ++)
    {
        for (int j = 0; j < m_col; j++)
        {
            std::cout << m_maze[i][j];
        }
        std::cout << "\n";
    }
}

