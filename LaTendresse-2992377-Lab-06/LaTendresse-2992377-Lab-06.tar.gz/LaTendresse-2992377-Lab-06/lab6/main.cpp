//
//  main.cpp
//  lab6
//  the main.cpp is used to run the program and take in the name of the file as an argument
//  Created by Matt LaTendresse on 3/31/21.
//

#include <iostream>
#include "MazeWalker.h"

int main(int argc, char* argv[])
{
    if (argc !=2)
    {
        std::cout << "ERROR: Invalid amount of command line arguments\n";
        exit(1);
    }
    else
    {
        MazeWalker maze(argv[1]);
        maze.solveMaze();
    }

    return 0;
}

