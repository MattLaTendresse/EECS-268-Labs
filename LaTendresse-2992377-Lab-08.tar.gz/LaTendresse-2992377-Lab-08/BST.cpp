
template <typename ItemType,typename KeyType>
BST<ItemType,KeyType>::BST()
{
    m_root = nullptr;
}

template <typename ItemType, typename KeyType>
BST<ItemType, KeyType>::~BST()
{
    clear();
}

template <typename ItemType, typename KeyType>
BSTNode<ItemType>* BST<ItemType, KeyType>::getRoot()
{
    return m_root;
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::add(ItemType entry)
{
    if (m_root == nullptr)
       {
           m_root = new BSTNode<ItemType>(entry);
       }
       else
       {
           try
           {
               recAdd(entry, m_root);
           }
           catch (std::runtime_error& rte)
           {
               throw (std::runtime_error(rte.what()));
           }
       }
}


template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::recAdd(ItemType entry, BSTNode<ItemType> *subtree)
{
    if (subtree->getEntry() == entry)
       {
           throw(std::runtime_error("ERROR: Cannot add existing value\n"));
       }
       else if (subtree->getEntry() > entry)
       {
           if (subtree->getLeft() == nullptr)
           {
               BSTNode<ItemType>* newNodePtr = new BSTNode<ItemType>(entry);
               subtree->setLeft(newNodePtr);
           }
           else
           {
               recAdd(entry,subtree->getLeft());
           }
       }
       else
       {
           if (subtree->getRight() == nullptr)
           {
               BSTNode<ItemType>* newNodePtr = new BSTNode<ItemType>(entry);
               subtree->setRight(newNodePtr);
           }
           else
           {
               recAdd(entry,subtree->getRight());
           }
       }
}

template <typename ItemType, typename KeyType>
ItemType BST<ItemType,KeyType>::search(KeyType key) const
{
    try
       {
           return (recSearch(key,m_root));
       }
       catch (std::runtime_error& rte)
       {
           throw (std::runtime_error(rte.what()));
       }
}

template <typename ItemType, typename KeyType>
ItemType BST<ItemType,KeyType>::recSearch(KeyType key, BSTNode<ItemType>* subtree) const
{
    if (subtree == nullptr)
    {
        throw(std::runtime_error("ERROR: Given value is not present in Binary Search Tree\n"));
    }
    else if (subtree->getEntry()==key)
    {
        return (subtree->getEntry());
    }
    else if (subtree->getEntry() > key)
    {
        try
        {
            return(recSearch(key,subtree->getLeft()));
        }
        catch(const std::runtime_error& rte)
        {
            throw(std::runtime_error(rte.what()));
        }
    }
    else
    {
        try
        {
            return(recSearch(key,subtree->getRight()));
        }
        catch(const std::runtime_error& rte)
        {
            throw(std::runtime_error(rte.what()));
        }
    }
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::clear()
{
    recClear(m_root);
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::recClear(BSTNode<ItemType>* subtree)
{
    if (subtree == nullptr)
    {
        return;
    }
    else
    {
        recClear(subtree->getLeft());
        recClear(subtree->getRight());
        delete subtree;
        subtree = nullptr;
    }
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitPostOrder(void visit(ItemType)) const
{
    visitPost(visit,m_root);
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitPost(void visit(ItemType), BSTNode<ItemType>* subtree) const
{
    if (subtree == nullptr)
    {
        return;
    }
    visitPost(visit,subtree->getLeft());
    visitPost(visit,subtree->getRight());
    visit(subtree->getEntry());
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitPreOrder(void visit(ItemType)) const
{
    visitPre(visit,m_root);
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitPre(void visit(ItemType), BSTNode<ItemType>* subtree) const
{
    if (subtree == nullptr)
    {
        return;
    }
    visit(subtree->getEntry());
    visitPre(visit,subtree->getLeft());
    visitPre(visit,subtree->getRight());
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitInOrder(void visit(ItemType)) const
{
    visitIn(visit,m_root);
}

template <typename ItemType, typename KeyType>
void BST<ItemType,KeyType>::visitIn(void visit(ItemType), BSTNode<ItemType>* subtree) const
{
    if (subtree == nullptr)
    {
        return;
    }
    visitIn(visit,subtree->getLeft());
    visit(subtree->getEntry());
    visitIn(visit,subtree->getRight());
}

template <typename ItemType, typename KeyType>
bool BST<ItemType,KeyType>::booleanSearch(KeyType target) const
{
    return(booleanRecSearch(target,m_root));
}

template <typename ItemType, typename KeyType>
bool BST<ItemType,KeyType>::booleanRecSearch(KeyType target, BSTNode<ItemType>* subtree) const
{
    if(subtree == nullptr)
    {
        return(false);
    }
    else if (subtree->getEntry()==target)
    {
        return(true);
    }
    else if (subtree->getEntry() > target)
    {
        return (booleanRecSearch(target,subtree->getLeft()));
    }
    else
    {
        return(booleanRecSearch(target,subtree->getRight()));
    }
}


