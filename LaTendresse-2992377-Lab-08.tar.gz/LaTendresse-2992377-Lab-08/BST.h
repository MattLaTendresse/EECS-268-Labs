//
//  BST.h
//  lab8
//
//  Created by Matt LaTendresse on 4/21/21.
//

#ifndef BST_h
#define BST_
#include "BinarySearchTreeInterface.h"
#include "BSTNode.h"
#include <stdexcept>
#include <iostream>

template <typename ItemType, typename KeyType>
class BST : public BinarySearchTreeInterface<ItemType,KeyType>
{
  
private:
    BSTNode<ItemType>* m_root;
    void recAdd(ItemType entry, BSTNode<ItemType>* subtree);
    ItemType recSearch(KeyType key, BSTNode<ItemType>* subtree) const;
    void recClear(BSTNode<ItemType>* subtree);
    void visitPost(void visit(ItemType), BSTNode<ItemType>* subtree) const;
    void visitPre(void visit(ItemType), BSTNode<ItemType>* subtree) const;
    void visitIn(void visit(ItemType), BSTNode<ItemType>* subtree) const;
    void copy(BSTNode<ItemType>* subtree);
    
public:
    
    bool booleanSearch(KeyType target) const;

    bool booleanRecSearch(KeyType target, BSTNode<ItemType>* subtree) const;
    
    BST();
    BST(BST<ItemType,KeyType>* tree);
    ~BST();
    
    BSTNode<ItemType>* getRoot();
    
    //BSTInterface methods
    void add(ItemType entry);
    ItemType search(KeyType key) const;
    void clear();
    void visitPreOrder(void visit(ItemType)) const; //Visits each node in pre order
    void visitInOrder(void visit(ItemType)) const; //Visits each node in in order
    void visitPostOrder(void visit(ItemType)) const; //Visits each node in post order

};
#include "BST.cpp"
#endif /* BST_h */

