//
//  BSTNode.cpp
//  lab8
//
//  Created by Matt LaTendresse on 4/21/21.
//

template <typename T>
BSTNode<T>::BSTNode(T entry)
{
    m_entry = entry;
    m_left = nullptr;
    m_right = nullptr;
}

template <typename T>
T BSTNode<T>::getEntry() const
{
    return m_entry;
}

template <typename T>
void BSTNode<T>::setEntry(T entry)
{
    m_entry = entry;
}

template <typename T>
BSTNode<T>* BSTNode<T>::getLeft() const
{
        return m_left;
}

template <typename T>
BSTNode<T>* BSTNode<T>::getRight() const
{
        return m_right;
}

template <typename T>
void BSTNode<T>::setLeft(BSTNode<T>* left)
{
    m_left = left;
}

template <typename T>
void BSTNode<T>::setRight(BSTNode<T>* right)
{
    m_right = right;
}


