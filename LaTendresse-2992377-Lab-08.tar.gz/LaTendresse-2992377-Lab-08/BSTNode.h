//
//  BSTNode.h
//  lab8
//
//  Created by Matt LaTendresse on 4/21/21.
//

#ifndef BSTNode_h
#define BSTNode_h
template <typename T>
class BSTNode
{
private:
    T m_entry;
    BSTNode<T>* m_left;
    BSTNode<T>* m_right;
    
public:
    BSTNode(T m_entry);
    //@post - sets entry to m_entry and sets m_next to null

    T getEntry() const;
    //@pre - m_entry must have valid T stored
    //@post - does not change m_entry
    //@return - returns the value in m_entry

    void setEntry(T entry);
    //@post - sets entry into m_entry
    //@param - entry is the T to be added into m_entry
    
    BSTNode<T>* getLeft() const;
    //@pre - m_left must have a valid Node stored
    //@post - makes no changes
    //@return - returns the Node stored in m_next

    BSTNode<T>* getRight() const;
    //@pre - m_right must have a valid Node stored
    //@post - makes no changes
    //@return - returns the Node stored in m_next

    void setLeft(BSTNode<T>* left);
    //@post - sets left as m_left
    //@param - next is the Node to be placed into m_next
    
    void setRight(BSTNode<T>* right);
    //@post - sets left as m_left
    //@param - next is the Node to be placed into m_next
};

#include "BSTNode.cpp"
#endif /* BSTNode_h */

