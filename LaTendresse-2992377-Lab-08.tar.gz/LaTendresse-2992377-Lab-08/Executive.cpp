//
//  Executive.cpp
//  lab8
//
//  Created by Matt LaTendresse on 4/21/21.
//

#include <stdio.h>
#include "Executive.h"


Executive::Executive(std::string file)
{
    m_tree = new BST<pokemon, int>;
    readAdd(file);
    run();
}

void Executive::readAdd(std::string file)
{
    std::ifstream inFile;
    std::string tempUS,tempJP;
    int tempID=0;
    inFile.open(file);
    if (inFile.is_open())
    {
        while (inFile >> tempUS >> tempID >> tempJP)
        {
            pokemon newPokemon;
            newPokemon.setUSName(tempUS);
            newPokemon.setNum(tempID);
            newPokemon.setJAPName(tempJP);
            try
            {
                m_tree->add(newPokemon);
            }
            catch (std::runtime_error& rte)
            {
                std::cout << "There was a repeated Pokemon in the given file. It was not recoppied\n\n";
            }
        }
    }
    else
    {
        std::cout << "ERROR: Unable to open file\n";
        exit(1);
    }
}

void Executive::run()
{
    std::string choices;
    do
    {
        std::cout << "What would you like to do?\n";
        std::cout << "Please type in an option from below,\n";
        std::cout << "Options: Search, Add, Print, Quit: ";
        std::cin >> choices;
        std::cout <<'\n';
        if (choices == "Search")
            {
                search(m_tree);
            }
            else if (choices == "Add")
            {
                add(m_tree);
            }
            else if (choices == "Print")
            {
                printInteraction(m_tree);
            }
            else if (choices =="Quit")
            {
                exit(1);
            }
            else
            {
                std::cout << "Hmm. It seems you didn't input in the correct response. Let's try again!\n";
            }
    }while(choices != "Quit");
}

void Executive::printInteraction(BST<pokemon, int> *tree)
{
    std::string choice;
    std::cout << "Which order would you like to print? (In, Post, Pre): ";
    std::cin >> choice;
    std::cout << '\n';

        if (choice == "In")
        {
            printInTree(tree);
        }
        else if (choice == "Post")
        {
            printPostTree(tree);
        }
        else if (choice == "Pre")
        {
            printPreTree(tree);
        }
        else
        {
            std::cout << "Hmm. It seems you didn't input in the correct response. Let's try again!\n";
        }
}


void Executive::search(BST<pokemon,int> *tree)
{
    int pokedexNum;
    pokemon found;
    std::cout << "Input the pokedex number of the Pokemon you are looking for: ";
    std::cin >> pokedexNum;

    try
    {
        found = tree->search(pokedexNum);
        std::cout << found.getusName() << '\t';
        std::cout << found.getidNum() << '\t';
        std::cout << found.getjapName() << '\n';
    }
    catch (std::runtime_error& rte)
    {
        std::cout << "Sorry. It seems the Pokemon you are looking for is not in the pokedex.\n";
    }
}

void Executive::add(BST<pokemon,int> *tree)
{
    std::string usName, jName;
    int idNum;
    pokemon newPokemon;

    std::cout << "What is the American Name of the Pokemon? ";
    std::cin >> usName;
    std::cout << "\nWhat is the pokedex number of the Pokemon? ";
    std::cin >> idNum;
    std::cout << "\nWhat is the Japanese Name of the Pokemon? ";
    std::cin >> jName;

    newPokemon.setUSName(usName);
    newPokemon.setNum(idNum);
    newPokemon.setJAPName(jName);

    try
    {
        tree->add(newPokemon);
        std::cout <<"\nPokemn successfully added!\n";
    }
    catch (std::runtime_error& rte)
    {
        std::cout << "\nSorry. It seems that the Pokemon you are trying to add is already in the pokedex.\n";
    }
}

void Executive::printPostTree(BST<pokemon,int> *tree)
{
    tree->visitPostOrder(pokemon::print);
}

void Executive::printPreTree(BST<pokemon,int> *tree)
{
    tree->visitPreOrder(pokemon::print);
}

void Executive::printInTree(BST<pokemon,int> *tree)
{
    tree->visitInOrder(pokemon::print);
}

