//
//  Executive.h
//  lab8
//
//  Created by Matt LaTendresse on 4/21/21.
//

#ifndef Executive_h
#define Executive_h
#include "pokemon.h"
#include "BST.h"
#include "BSTNode.h"
#include <iostream>
#include <fstream>
#include <string>

class Executive
{
private:
    BST<pokemon,int>* m_tree;
    BST<pokemon,int>* m_copiedTree;
    

public:
    Executive(std::string file);
    
    void readAdd(std::string file);
    void run();
    void search(BST<pokemon,int>* tree);
    void add(BST<pokemon,int>* tree);
    void printInteraction(BST<pokemon,int>* tree);
    void menu(BST<pokemon,int>* tree);
    void printPostTree(BST<pokemon,int>* tree);
    void printPreTree(BST<pokemon,int> *tree);
    void printInTree(BST<pokemon,int> *tree);

};
#endif /* Executive_h */

