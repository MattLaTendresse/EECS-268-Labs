//
//  main.cpp
//  lab8
//
//  Created by Matt LaTendresse on 4/20/21.
//

#include "Executive.h"
#include <iostream>

int main(int argc, char *argv[])
{
    if (argc!=2)
    {
	 std::cout << "ERROR: Invalid amount of command line arguments1\n";
        exit(1);
    }
    else
    {
        Executive exec(argv[1]);
    }
    return 0;
}

