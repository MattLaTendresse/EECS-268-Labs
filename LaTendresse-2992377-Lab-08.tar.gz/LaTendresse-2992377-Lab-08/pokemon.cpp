//
//  pokemon.cpp
//  lab8
//
//  Created by Matt LaTendresse on 4/20/21.
//

#include <stdio.h>
#include "pokemon.h"

pokemon::pokemon()
{
    m_usName = "";
    m_idNum =0;
    m_japName = "";
}

void pokemon::setUSName(std::string usName)
{
    m_usName = usName;
}

void pokemon::setNum(int num)
{
    m_idNum = num;
}

void pokemon::setJAPName(std::string japName)
{
    m_japName = japName;
}

std::string pokemon::getusName() const
{
    return m_usName;
}

int pokemon::getidNum() const
{
    return m_idNum;
}

std::string pokemon::getjapName() const
{
    return m_japName;
}

bool pokemon::operator>(const pokemon &rhs) const
{
    if (m_idNum > rhs.getidNum())
        {
            return true;
        }
        else
        {
            return false;
        }
}

bool pokemon::operator==(const pokemon& rhs) const
{
    if(m_idNum == rhs.getidNum())
    {
        return true;
    }
       else{
       return false;
    }
}

bool pokemon::operator==(int rhs) const
{
    if (m_idNum == rhs)
        {
            return true;
        }
        else
        {
            return false;
        }
}

bool pokemon::operator>(int rhs) const
{
    if (m_idNum > rhs)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void pokemon::print(pokemon guy)
{
    std::cout << guy.getusName()<< '\t';
    std::cout << guy.getidNum() << '\t';
    std::cout << guy.getjapName() << '\n';
}

