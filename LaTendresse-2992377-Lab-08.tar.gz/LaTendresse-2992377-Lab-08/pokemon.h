//
//  pokemon.h
//  lab8
//
//  Created by Matt LaTendresse on 4/20/21.
//

#ifndef pokemon_h
#define pokemon_h
#include <string>
#include <iostream>
class pokemon {
private:
    
    std::string m_usName;
    int m_idNum;
    std::string m_japName;
    
public:
    pokemon();
    
    //setters
    /**
      * @brief sets m_usName with passed in name
      * @param name to be set to m_usName
     */
    void setUSName(std::string usName);
    
    /**
         * @brief sets m_idNum with passed in num
         * @param num to be set to m_idNum
         */
    void setNum(int num);
    
    /**
         * @brief sets m_japName with passed in name
         * @param japName to be set to m_japName
         */
    void setJAPName(std::string japName);
    
    
    //getters
    /**
         * @brief gets the US name of a pokemon
         * @return returns m_usName
         */
    std::string getusName() const;
    
    /**
         * @brief gets the id num of a pokemon
         * @return returns m_idNum
        */
    int getidNum() const;
    
    /**
         * @brief gets the jap name of a pokemon
         * @return returns m_japName
         */
    std::string getjapName() const;
    
    //operator overloaders
    
    /**
     * @brief compares this Pokemon's idNum with rhs' idNum
     * @param rhs Pokemon being compared with this Pokemon
     * @return true if this Pokemon's idNum is greater than the rhs, false otherwise
     */
    bool operator>(const pokemon& rhs) const;
    
    /**
        * @brief compares this Pokemon's idNum with rhs' idNum
        * @param rhs Pokemon being compared with this Pokemon
        * @return true if this Pokemon's idNum is equal to the rhs, false otherwise
        */
    bool operator==(const pokemon& rhs) const;
    
    /**
         * @brief compares this Pokemon's idNum with given idNum
         * @param rhs idNum being compared with this Pokemon's idNum
         * @return true if this Pokemon's idNum is equal to the rhs, false otherwise
         */
    bool operator==(int rhs) const;
    
    /**
         * @brief compares this Pokemon's idNum with given idNum
         * @param rhs idNum being compared with this Pokemon's idNum
         * @return true if this Pokemon's idNum is greater than the rhs, false otherwise
         */
    bool operator>(int rhs) const;
    
    /**
     * @brief prints out the names and idNum of passed in Pokemon, not this Pokemon
     * @param  pokemon guy  info to be printed
     */
    static void print(pokemon guy);
};

#endif /* pokemon_h */

